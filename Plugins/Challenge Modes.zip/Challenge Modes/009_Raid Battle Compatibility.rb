#===============================================================================
# Raid Battle Compatibility Fix
# Ensures proper Pokemon storage when raid battle plugins are installed
#===============================================================================

# Only apply this fix if raid battle functionality is detected
if defined?(RaidBattle) || (defined?(Battle) && Battle.instance_methods.include?(:raid))
  
  class Battle
    # Override storage for raid battle compatibility
    alias challenge_modes_pbStorePokemon pbStorePokemon if method_defined?(:pbStorePokemon)
    def pbStorePokemon(pkmn)
      # In raid battles, force normal party storage behavior
      if respond_to?(:raid) && @raid
        # Check if party has space for raid battles
        if $player.party.length < Settings::MAX_PARTY_SIZE
          return true  # Allow storage in party
        else
          return false # Party full, will go to PC
        end
      end
      
      # For non-raid battles, use the original method
      if respond_to?(:challenge_modes_pbStorePokemon)
        return challenge_modes_pbStorePokemon(pkmn)
      else
        return $player.party.length < Settings::MAX_PARTY_SIZE
      end
    end
  end
  
end
